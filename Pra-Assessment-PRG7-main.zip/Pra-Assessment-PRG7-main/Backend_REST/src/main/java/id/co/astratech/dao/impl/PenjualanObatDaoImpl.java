package id.co.astratech.dao.impl;

import id.co.astratech.constant.PenjualanObatConstant;
import id.co.astratech.dao.PenjualanObatDao;
import id.co.astratech.model.Obat;
import id.co.astratech.model.PenjualanObat;
import id.co.astratech.repository.ObatRepository;
import id.co.astratech.repository.PenjualanObatRepository;
import id.co.astratech.vo.PenjualanObatVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PenjualanObatDaoImpl implements PenjualanObatDao {

    @Autowired
    private PenjualanObatRepository penjualanObatRepository;

    @Autowired
    private ObatRepository obatRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<PenjualanObatVo> getAllObat() {
        Iterable<PenjualanObat> penjualanObat = penjualanObatRepository.findAll();
        List<PenjualanObatVo> penjualanObatVos = new ArrayList<>();
        for (PenjualanObat item : penjualanObat) {
            PenjualanObatVo penjualanObatVo = new PenjualanObatVo(item);

            Obat obat = obatRepository.findById(item.getIdObat()).orElse(null);
            if (obat != null) {
                penjualanObatVo.setNamaObat(obat.getNamaObat());
                penjualanObatVo.setHargaObat(obat.getHargaObat());
            } else {
                // Handle case where obat is not found
                penjualanObatVo.setNamaObat("Obat tidak ditemukan");
                penjualanObatVo.setHargaObat(0.0);
            }

            penjualanObatVos.add(penjualanObatVo);
        }
        return penjualanObatVos;
    }

    @Override
    public String getLastId(Integer tahun) {
        String lastId = null;
        try {
            lastId = jdbcTemplate.queryForObject(PenjualanObatConstant.qGetLastId, String.class, tahun);
        } catch (Exception e) {
            // Handle exception
            e.printStackTrace();
        }
        return lastId;
    }

    @Override
    public Double getTotalTransaksi() {
        List<PenjualanObat> penjualanObatList = penjualanObatRepository.findAll();
        Double totalTransaksi = 0.0;
        for (PenjualanObat penjualanObat : penjualanObatList) {
            Double hargaTotal = penjualanObat.getTotal();
            totalTransaksi += hargaTotal != null ? hargaTotal : 0.0;
        }
        return totalTransaksi;
    }
}
