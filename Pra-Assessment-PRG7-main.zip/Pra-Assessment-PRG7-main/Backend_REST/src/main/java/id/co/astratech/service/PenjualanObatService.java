package id.co.astratech.service;

import id.co.astratech.model.PenjualanObat;
import id.co.astratech.response.DtoResponse;

public interface PenjualanObatService {

    DtoResponse getAllTransaksi();

    DtoResponse saveTransaksi(PenjualanObat penjualanObat);

    DtoResponse getAllTransaksiByObat();

    DtoResponse getAllTransaksiSum();

    DtoResponse getTotalTransaksi();
}
