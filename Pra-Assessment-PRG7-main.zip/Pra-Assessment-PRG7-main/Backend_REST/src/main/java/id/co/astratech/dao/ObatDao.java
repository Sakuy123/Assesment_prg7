package id.co.astratech.dao;

import id.co.astratech.vo.ObatVo;

import java.util.List;

public interface ObatDao {

    public List<ObatVo> getAllObat();

}
