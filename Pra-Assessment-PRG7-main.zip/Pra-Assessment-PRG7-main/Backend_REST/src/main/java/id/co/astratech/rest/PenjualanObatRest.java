package id.co.astratech.rest;

import id.co.astratech.model.PenjualanObat;
import id.co.astratech.response.DtoResponse;
import id.co.astratech.service.PenjualanObatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/penjualan")
@CrossOrigin
public class PenjualanObatRest {

    private final PenjualanObatService penjualanObatService;

    @Autowired
    public PenjualanObatRest(PenjualanObatService penjualanObatService) {
        this.penjualanObatService = penjualanObatService;
    }

    @GetMapping("/getAllTransaksi")
    public DtoResponse getAllTransaksi() {
        return penjualanObatService.getAllTransaksi();
    }

    @GetMapping("/getTotalTransaksi")
    public DtoResponse getTotalTransaksi() {
        return penjualanObatService.getTotalTransaksi();
    }

    @PostMapping("/saveTransaksi")
    public DtoResponse saveTransaksi(@RequestBody PenjualanObat penjualanObat) {
        return penjualanObatService.saveTransaksi(penjualanObat);
    }
}
