package id.co.astratech.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Entity
@Table(name = "TrPenjualanObat")
@NoArgsConstructor
@AllArgsConstructor
public class PenjualanObat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdTransaksi")
    private String idTransaksi;

    @Column(name = "IdObat")
    private Integer idObat;

    @Column(name = "QtyObat")
    private Integer qty;

    @Column(name = "HargaTotal")
    private Double total;

    @Column(name = "Tanggal")
    private Date tanggalTransaksi;

}
