package id.co.astratech.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "MsObat")
@NoArgsConstructor
@AllArgsConstructor
public class Obat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdObat")
    private Integer idObat;

    @Column(name = "NamaObat")
    private String namaObat;

    @Column(name = "TipeObat")
    private Integer tipeObat;

    @Column(name = "Indikasi")
    private String indikasi;
    @Column(name = "Stok")
    private Integer stok;

    @Column(name = "StokMin")
    private Integer stokMin;

    @Column(name = "HargaObat")
    private Double hargaObat;

    @Column(name = "StatusObat")
    private Integer status;


}
