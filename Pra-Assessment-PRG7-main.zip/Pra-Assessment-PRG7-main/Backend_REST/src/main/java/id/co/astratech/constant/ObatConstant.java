package id.co.astratech.constant;

public class ObatConstant {
    public static final String qGetAllObat = "SELECT * FROM MsObat WHERE StatusObat = 1 ORDER BY Stok DESC";

    public static final String qGetObatMaxStock = "SELECT * FROM penjualan_obat ORDER BY stok DESC";


}
