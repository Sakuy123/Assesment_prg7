package id.co.astratech.vo;

import id.co.astratech.model.PenjualanObat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PenjualanObatVo {

    private String idTransaksi;
    private Integer idObat;
    private String namaObat;
    private Double hargaObat;
    private Integer qty;
    private Double total;
    private Date tanggalTransaksi;

    public PenjualanObatVo(PenjualanObat penjualanObat) {
        this.idTransaksi = penjualanObat.getIdTransaksi();
        this.idObat = penjualanObat.getIdObat();
        this.qty = penjualanObat.getQty();
        this.total = penjualanObat.getTotal();
        this.tanggalTransaksi = penjualanObat.getTanggalTransaksi();
    }
}
