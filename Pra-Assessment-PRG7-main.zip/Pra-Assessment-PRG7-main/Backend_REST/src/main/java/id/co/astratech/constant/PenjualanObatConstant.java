package id.co.astratech.constant;

public class PenjualanObatConstant {

    public static final String qGetLastId = "SELECT MAX(IdTransaksi) FROM TrPenjualanObat WHERE IdTransaksi LIKE CONCAT(:tahun, '%')";


    public static final String qGetSumByIdObat =
            "SELECT " +
                    "    t.idObat, " +
                    "    l.NamaObat AS namaObat, " +
                    "    COUNT(*) AS jumlah, " +
                    "    SUM(l.hargaObat) AS totalHarga " +
                    "FROM " +
                    "    TrPenjualanObat t " +
                    "JOIN " +
                    "    MsObat l ON t.idObat = l.idObat " +
                    "GROUP BY " +
                    "    t.idObat, " +
                    "    l.NamaObat " +
                    "ORDER BY " +
                    "    jumlah DESC";




}
