package id.co.astratech.repository;

import id.co.astratech.model.Obat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

import static id.co.astratech.constant.ObatConstant.*;

@Repository
public interface ObatRepository extends JpaRepository<Obat, Integer> {

    @Query(value = qGetAllObat, nativeQuery = true)
    public List<Obat> getAllObat();

    @Query(value = qGetObatMaxStock, nativeQuery = true)
    public List<Obat> findAllOrderByStokDesc();
}
