package id.co.astratech.service.impl;

import id.co.astratech.dao.PenjualanObatDao;
import id.co.astratech.model.Obat;
import id.co.astratech.model.PenjualanObat;
import id.co.astratech.repository.ObatRepository;
import id.co.astratech.repository.PenjualanObatRepository;
import id.co.astratech.response.DtoResponse;
import id.co.astratech.service.PenjualanObatService;
import id.co.astratech.vo.PenjualanObatVo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class PenjualanObatServiceImpl implements PenjualanObatService {

    private final PenjualanObatDao penjualanObatDao;
    private final PenjualanObatRepository penjualanObatRepository;
    private final ObatRepository obatRepository;

    @Autowired
    public PenjualanObatServiceImpl(PenjualanObatDao penjualanObatDao, PenjualanObatRepository penjualanObatRepository, ObatRepository obatRepository) {
        this.penjualanObatDao = penjualanObatDao;
        this.penjualanObatRepository = penjualanObatRepository;
        this.obatRepository = obatRepository;
    }

    @Override
    public DtoResponse getAllTransaksi() {
        List<PenjualanObatVo> data = penjualanObatDao.getAllObat();
        return data != null ? new DtoResponse(200, data, "Sukses") : new DtoResponse(500, null, "Error saat mengambil data");
    }

    @Override
    public DtoResponse saveTransaksi(PenjualanObat penjualanObat) {
        try {
            Obat obat = obatRepository.findById(penjualanObat.getIdObat()).orElse(null);
            if (obat == null) {
                return new DtoResponse(400, penjualanObat, "Obat tidak ditemukan");
            }

            int newStok = obat.getStok() - penjualanObat.getQty();
            if (newStok < 0) {
                return new DtoResponse(400, penjualanObat, "Stok obat tidak mencukupi");
            }

            obat.setStok(newStok);
            obatRepository.save(obat);

            penjualanObat.setTotal(penjualanObat.getQty() * obat.getHargaObat());
            penjualanObat.setIdTransaksi(getIdTransaksi());
            penjualanObat.setTanggalTransaksi(new Date());
            penjualanObatRepository.save(penjualanObat);

            return new DtoResponse(200, penjualanObat, "Sukses Menyimpan data");
        } catch (Exception e) {
            return new DtoResponse(500, penjualanObat, "Gagal Menyimpan Data");
        }
    }

    @Override
    public DtoResponse getAllTransaksiByObat() {
        // Implement logic to retrieve all transactions by drug
        return null;
    }

    @Override
    public DtoResponse getAllTransaksiSum() {
        // Implement logic to retrieve sum of transactions
        return null;
    }

    private String getIdTransaksi() {
        Integer tahunSekarang = Calendar.getInstance().get(Calendar.YEAR);
        String tahunString = String.valueOf(tahunSekarang);

        // Get the last transaction ID
        String lastId = penjualanObatDao.getLastId(tahunSekarang);

        int newIncrement = 1;
        if (lastId != null) {
            String lastIncrementStr = lastId.substring(4);
            newIncrement = Integer.parseInt(lastIncrementStr) + 1;
        }

        return String.format("%s%04d", tahunString, newIncrement);
    }

    @Override
    public DtoResponse getTotalTransaksi() {
        Double total = penjualanObatDao.getTotalTransaksi();
        return new DtoResponse(200, total, "Sukses");
    }
}
