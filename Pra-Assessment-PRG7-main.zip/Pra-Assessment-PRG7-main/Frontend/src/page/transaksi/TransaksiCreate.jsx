import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { listObat } from "../../util/ObatService"; // Assuming you have this service to fetch the list of obat
import { saveTransaksi } from "../../util/TransaksiService";

export default function TransaksiCreate() {
  const navigate = useNavigate();
  const [idObat, setIdObat] = useState("");
  const [qty, setQty] = useState(""); // Initialize qty as 0
  const [selectedObat, setSelectedObat] = useState(null);
  const [price, setPrice] = useState(0);
  const [total, setTotal] = useState(0);
  const [obats, setObats] = useState([]);

  useEffect(() => {
    listObat()
      .then((response) => {
        setObats(response.data.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const formatCurrency = (number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(number);
  };

  const handleObatChange = (event) => {
    const selectedId = event.target.value;
    setIdObat(selectedId);
    const selectedObat = obats.find(obat => String(obat.idObat) === selectedId);
    if (selectedObat) {
      const hargaObat = parseFloat(selectedObat.hargaObat) || 0;
      setPrice(hargaObat);
      setTotal(hargaObat * parseFloat(qty) || 0);
    } else {
      setPrice(0);
      setTotal(0);
    }
  };

  const handleQtyChange = (event) => {
    const quantity = parseFloat(event.target.value) || 0;
    setQty(quantity);
    if (price) {
      setTotal(price * quantity || 0);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!idObat || !qty) {
      alert("Field Tidak boleh kosong");
      return;
    }

    try {
      const penjualanObat = {
        idObat,
        qty,
      };

      saveTransaksi(penjualanObat).then(() => {
        navigate("/transaksi");
      });
    } catch (error) {
      alert("Tidak bisa terhubung dengan server");
    }
  };

  return (
    <div className="container my-4">
      <div className="row">
        <div className="col-md-8 mx-auto rounded border p-4">
          <h2>Create Transaksi</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-3 row">
              <label className="col-sm-4 col-form-label">Nama Obat</label>
              <div className="col-sm-8">
                <select className="form-select" name="idObat" id="idObat" value={idObat} onChange={handleObatChange}>
                  <option value="" disabled>
                    Pilih Obat
                  </option>
                  {obats.map((obat) => (
                    <option key={obat.idObat} value={obat.idObat}>
                      {obat.namaObat}
                    </option>
                  ))}
                </select>
                <span className="text-danger"></span>
              </div>
            </div>

            <div className="mb-3 row">
              <label className="col-sm-4 col-form-label">Harga</label>
              <div className="col-sm-8">
                <input className="form-control" type="text" value={formatCurrency(price)} readOnly />
              </div>
            </div>

            <div className="mb-3 row">
              <label className="col-sm-4 col-form-label">Qty</label>
              <div className="col-sm-8">
                <input className="form-control" type="number" name="qty" id="qty" value={qty} onChange={handleQtyChange} />
                <span className="text-danger"></span>
              </div>
            </div>

            <div className="mb-3 row">
              <label className="col-sm-4 col-form-label">Total</label>
              <div className="col-sm-8">
                <input className="form-control" type="text" value={formatCurrency(total)} readOnly />
              </div>
            </div>

            <div className="row">
              <div className="offset-sm-4 col-sm-4 d-grid">
                <button type="submit" className="btn btn-primary">
                  Submit
                </button>
              </div>
              <div className="col-sm-4 d-grid">
                <Link className="btn btn-secondary" to="/transaksi" role="button">
                  Cancel
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
