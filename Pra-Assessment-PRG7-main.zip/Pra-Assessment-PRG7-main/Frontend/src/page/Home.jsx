import React from 'react'

export default function Home() {
  return (
    <div className='container my-4'>
        <h2>Wellcome to my web</h2>
    </div>
  )
}
