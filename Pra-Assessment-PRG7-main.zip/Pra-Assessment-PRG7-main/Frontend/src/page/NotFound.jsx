import React from "react";

export default function NotFound() {
  return (
    <div className="container my-4">
      <h2>Page Not Found</h2>
    </div>
  );
}
