import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { listObat, deleteObat } from "../../util/ObatService";
import Swal from "sweetalert2";

export default function ObatIndex() {
  const [obats, setObats] = useState([]);
  const [filterQuery, setFilterQuery] = useState("");
  const [filteredObats, setFilteredObats] = useState([]);

  useEffect(() => {
    listObat()
      .then((response) => {
        setObats(response.data.data);
        setFilteredObats(response.data.data); // initialize the filteredObats with all data
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  useEffect(() => {
    setFilteredObats(
      obats.filter(obat =>
        obat.namaObat.toLowerCase().includes(filterQuery.toLowerCase())
      )
    );
  }, [filterQuery, obats]);

  function handleDelete(idObat) {
    Swal.fire({
      title: "Apakah anda yakin?",
      text: "Ingin menghapus data ini",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.isConfirmed) {
        try {
          deleteObat(idObat);
          Swal.fire({
            title: "Sukses!",
            text: "data anda sudah berhasil di hapus.",
            icon: "success",
          }).then(() => {
            window.location.reload();
            console.log(idObat);
          });
        } catch (error) {
          console.error(error);
          Swal.fire({
            title: "Error!",
            text: "Terjadi error saat menghapus data.",
            icon: "error",
          });
        }
      }
    });
  }

  return (
    <div className="container my-4">
      <h2>Obat Index</h2>
      <div className="row mb-3">
        <div className="col">
          <Link className="btn btn-primary me-1" role="button" to="/Obat/create">
            Create
          </Link>
        </div>
        <div className="col">
          <input
            type="text"
            className="form-control"
            placeholder="Filter by name"
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
          />
        </div>
      </div>

      <table className="table">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Tipe</th>
            <th>Indikasi</th>
            <th>Stok</th>
            <th>Stok Min</th>
            <th>Harga</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {filteredObats.map((obat, index) => (
            <tr key={obat.idObat}>
              <td>{index + 1}</td>
              <td>{obat.namaObat}</td>
              <td>{obat.tipeObat}</td>
              <td>{obat.indikasi}</td>
              <td>{obat.stok}</td>
              <td>{obat.stokMin}</td>
              <td>{obat.hargaObat}</td>
              <td style={{ width: "10px", whiteSpace: "nowrap" }}>
                <Link className="btn btn-primary btn-sm me-1" to={`/Obat/update/${obat.idObat}`}>
                  Edit
                </Link>
                <button type="button" className="btn btn-danger btn-sm" onClick={() => handleDelete(obat.idObat)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
