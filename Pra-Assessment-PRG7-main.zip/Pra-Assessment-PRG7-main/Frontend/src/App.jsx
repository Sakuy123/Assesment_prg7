import { useState } from "react";
import Navbar from "./component/layout";
import Home from "./page/Home";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NotFound from "./page/NotFound";
import ObatIndex from "./page/Obat/ObatIndex";
import ObatCreate from "./page/Obat/ObatCreate";
import ObatUpdate from "./page/Obat/ObatUpdate";
import TransaksiIndex from "./page/transaksi/TransaksiIndex";
import TransaksiCreate from "./page/transaksi/TransaksiCreate";

function App() {
  const [count, setCount] = useState(0);

  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Obat" element={<ObatIndex />} />
        <Route path="/Obat/create" element={<ObatCreate />} />
        <Route path="/Obat/update/:idObat" element={<ObatUpdate />} />
        <Route path="/transaksi" element={<TransaksiIndex />} />
        <Route path="/transaksi/create" element={<TransaksiCreate />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>  
  );
}

export default App;
